import Opcoes.IniciaJogo;

public class JogoBurro {

    public static void main(String[] args) {
   
        IniciaJogo start = new IniciaJogo();   
    }
    
}
