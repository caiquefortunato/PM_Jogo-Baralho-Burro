package Util;

import Baralho.Valor;
import Burro.Rodada;
import Usuarios.Jogador;
import java.util.ArrayList;
import java.util.List;

public class Util {

    // Funcao limpa o visor do terminal onde o programa eh executado
    public static void limpaTela() {
        for(int i = 0; i < 20; i++){
            System.out.println();
        }
    }
    
}
